﻿namespace Crud_Serializzato
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReadVote = new System.Windows.Forms.Button();
            this.CreateVote = new System.Windows.Forms.Button();
            this.UpdateVote = new System.Windows.Forms.Button();
            this.DelateVote = new System.Windows.Forms.Button();
            this.BoxVoteValue = new System.Windows.Forms.TextBox();
            this.prezzo_prodotto = new System.Windows.Forms.Label();
            this.BoxSubjectName = new System.Windows.Forms.TextBox();
            this.nome_art = new System.Windows.Forms.Label();
            this.BoxStudentName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BoxClassName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.EXIT = new System.Windows.Forms.Button();
            this.BoxModStudentName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SearchVote = new System.Windows.Forms.Button();
            this.BoxSearchVote = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ReadVote
            // 
            this.ReadVote.Location = new System.Drawing.Point(120, 151);
            this.ReadVote.Name = "ReadVote";
            this.ReadVote.Size = new System.Drawing.Size(75, 64);
            this.ReadVote.TabIndex = 53;
            this.ReadVote.Text = "READ VOTE";
            this.ReadVote.UseVisualStyleBackColor = true;
            this.ReadVote.Click += new System.EventHandler(this.ReadVote_Click);
            // 
            // CreateVote
            // 
            this.CreateVote.Location = new System.Drawing.Point(30, 151);
            this.CreateVote.Name = "CreateVote";
            this.CreateVote.Size = new System.Drawing.Size(75, 64);
            this.CreateVote.TabIndex = 52;
            this.CreateVote.Text = "CREATE VOTE";
            this.CreateVote.UseVisualStyleBackColor = true;
            this.CreateVote.Click += new System.EventHandler(this.CreateVote_Click);
            // 
            // UpdateVote
            // 
            this.UpdateVote.Location = new System.Drawing.Point(227, 151);
            this.UpdateVote.Name = "UpdateVote";
            this.UpdateVote.Size = new System.Drawing.Size(76, 64);
            this.UpdateVote.TabIndex = 51;
            this.UpdateVote.Text = "UPDATE VOTE";
            this.UpdateVote.UseVisualStyleBackColor = true;
            this.UpdateVote.Click += new System.EventHandler(this.UpdateVote_Click);
            // 
            // DelateVote
            // 
            this.DelateVote.Location = new System.Drawing.Point(311, 151);
            this.DelateVote.Name = "DelateVote";
            this.DelateVote.Size = new System.Drawing.Size(76, 64);
            this.DelateVote.TabIndex = 50;
            this.DelateVote.Text = "DELETE VOTE";
            this.DelateVote.UseVisualStyleBackColor = true;
            this.DelateVote.Click += new System.EventHandler(this.DelateVote_Click);
            // 
            // BoxVoteValue
            // 
            this.BoxVoteValue.Location = new System.Drawing.Point(237, 102);
            this.BoxVoteValue.Name = "BoxVoteValue";
            this.BoxVoteValue.Size = new System.Drawing.Size(138, 20);
            this.BoxVoteValue.TabIndex = 57;
            // 
            // prezzo_prodotto
            // 
            this.prezzo_prodotto.AutoSize = true;
            this.prezzo_prodotto.Location = new System.Drawing.Point(234, 76);
            this.prezzo_prodotto.Name = "prezzo_prodotto";
            this.prezzo_prodotto.Size = new System.Drawing.Size(36, 13);
            this.prezzo_prodotto.TabIndex = 56;
            this.prezzo_prodotto.Text = "VOTE";
            // 
            // BoxSubjectName
            // 
            this.BoxSubjectName.Location = new System.Drawing.Point(40, 102);
            this.BoxSubjectName.Name = "BoxSubjectName";
            this.BoxSubjectName.Size = new System.Drawing.Size(138, 20);
            this.BoxSubjectName.TabIndex = 55;
            // 
            // nome_art
            // 
            this.nome_art.AutoSize = true;
            this.nome_art.Location = new System.Drawing.Point(37, 76);
            this.nome_art.Name = "nome_art";
            this.nome_art.Size = new System.Drawing.Size(89, 13);
            this.nome_art.TabIndex = 54;
            this.nome_art.Text = "SUBJECT NAME";
            // 
            // BoxStudentName
            // 
            this.BoxStudentName.Location = new System.Drawing.Point(40, 35);
            this.BoxStudentName.Name = "BoxStudentName";
            this.BoxStudentName.Size = new System.Drawing.Size(138, 20);
            this.BoxStudentName.TabIndex = 59;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 58;
            this.label1.Text = "STUDENT NAME";
            // 
            // BoxClassName
            // 
            this.BoxClassName.Location = new System.Drawing.Point(237, 35);
            this.BoxClassName.Name = "BoxClassName";
            this.BoxClassName.Size = new System.Drawing.Size(138, 20);
            this.BoxClassName.TabIndex = 61;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(234, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 60;
            this.label2.Text = "CLASS";
            // 
            // EXIT
            // 
            this.EXIT.Location = new System.Drawing.Point(666, 374);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(122, 64);
            this.EXIT.TabIndex = 62;
            this.EXIT.Text = "EXIT";
            this.EXIT.UseVisualStyleBackColor = true;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // BoxModStudentName
            // 
            this.BoxModStudentName.Location = new System.Drawing.Point(227, 258);
            this.BoxModStudentName.Name = "BoxModStudentName";
            this.BoxModStudentName.Size = new System.Drawing.Size(138, 20);
            this.BoxModStudentName.TabIndex = 63;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(224, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 13);
            this.label3.TabIndex = 64;
            this.label3.Text = "MODIFIED STUDENT NAME";
            // 
            // SearchVote
            // 
            this.SearchVote.Location = new System.Drawing.Point(30, 284);
            this.SearchVote.Name = "SearchVote";
            this.SearchVote.Size = new System.Drawing.Size(75, 64);
            this.SearchVote.TabIndex = 65;
            this.SearchVote.Text = "SEARCH VOTE";
            this.SearchVote.UseVisualStyleBackColor = true;
            this.SearchVote.Click += new System.EventHandler(this.SearchVote_Click);
            // 
            // BoxSearchVote
            // 
            this.BoxSearchVote.Location = new System.Drawing.Point(30, 258);
            this.BoxSearchVote.Name = "BoxSearchVote";
            this.BoxSearchVote.Size = new System.Drawing.Size(138, 20);
            this.BoxSearchVote.TabIndex = 66;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 67;
            this.label4.Text = "VOTE";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.BoxSearchVote);
            this.Controls.Add(this.SearchVote);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BoxModStudentName);
            this.Controls.Add(this.EXIT);
            this.Controls.Add(this.BoxClassName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BoxStudentName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BoxVoteValue);
            this.Controls.Add(this.prezzo_prodotto);
            this.Controls.Add(this.BoxSubjectName);
            this.Controls.Add(this.nome_art);
            this.Controls.Add(this.ReadVote);
            this.Controls.Add(this.CreateVote);
            this.Controls.Add(this.UpdateVote);
            this.Controls.Add(this.DelateVote);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ReadVote;
        private System.Windows.Forms.Button CreateVote;
        private System.Windows.Forms.Button UpdateVote;
        private System.Windows.Forms.Button DelateVote;
        private System.Windows.Forms.TextBox BoxVoteValue;
        private System.Windows.Forms.Label prezzo_prodotto;
        private System.Windows.Forms.TextBox BoxSubjectName;
        private System.Windows.Forms.Label nome_art;
        private System.Windows.Forms.TextBox BoxStudentName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BoxClassName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button EXIT;
        private System.Windows.Forms.TextBox BoxModStudentName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SearchVote;
        private System.Windows.Forms.TextBox BoxSearchVote;
        private System.Windows.Forms.Label label4;
    }
}

